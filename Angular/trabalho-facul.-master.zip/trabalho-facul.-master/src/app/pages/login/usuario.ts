export class Usuario{
    email!: string;
    nome!: string;
    senha!: string;
    confirmarsenha!: string;



}