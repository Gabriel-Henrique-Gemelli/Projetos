import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alunos',
  templateUrl: './alunos.component.html',
  styles: []
})
export class AlunosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
