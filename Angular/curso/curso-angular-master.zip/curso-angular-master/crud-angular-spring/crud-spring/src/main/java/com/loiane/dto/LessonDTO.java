package com.loiane.dto;

public record LessonDTO(
        Long id,
        String name,
        String youtubeUrl) {

}
