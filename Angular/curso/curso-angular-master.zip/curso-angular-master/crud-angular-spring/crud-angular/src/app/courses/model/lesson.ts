export interface Lesson {
  id: string;
  name: string;
  youtubeUrl: string;
}
