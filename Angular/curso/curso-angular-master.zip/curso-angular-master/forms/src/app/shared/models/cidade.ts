export interface Cidade {
  id: number;
  nome: string;
  estado: number;
}
